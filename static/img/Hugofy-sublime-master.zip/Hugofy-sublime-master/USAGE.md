#Hugofy

#Prepare Environment
Go to ```Prefrences > Package Settings > Hugofy > Settings -User``` and Default Directory and sitename 